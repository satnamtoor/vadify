package com.android.vadify.data.api.models

class UpdateLanguageSwitchRequestModel (
    val motherSwitch: Boolean
)