package com.android.vadify.data.api.models

data class CommandsRequestModel(

    val language: String? = "",
    val commandName: String? = "",
    val command1: String? = "",
    val command2: String? = "",
    val command3: String? = ""
)
