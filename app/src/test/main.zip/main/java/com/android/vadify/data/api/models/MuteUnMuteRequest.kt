package com.android.vadify.data.api.models

data class MuteUnMuteRequest(
    val mute: Boolean
)

