package com.android.vadify.data.api.models

data class ContactRequestModel(val contacts: List<String>)