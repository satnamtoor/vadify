package com.android.vadify.data.api.models

data class CallStatusRequest(
    val status: String
)

