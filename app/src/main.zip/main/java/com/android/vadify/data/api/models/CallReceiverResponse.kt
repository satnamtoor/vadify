package com.android.vadify.data.api.models

data class CallReceiverResponse(
    val data: Any,
    val message: String,
    val statusCode: Int
)


//{"statusCode":200,"data":{},"message":"Success!"}