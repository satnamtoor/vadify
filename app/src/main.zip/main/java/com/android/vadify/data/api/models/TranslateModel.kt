package com.android.vadify.data.api.models

data class TranslateModel(val key :String , val value : String)
