package com.android.vadify.data.api.enums

enum class ChatType(var value: Int) {
    NORMAL(0),
    SPEECH_TO_TEXT(1),
    VOICE_REOCRDING(2)
}



