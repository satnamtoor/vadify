package com.android.vadify.ui.dashboard.fragment.camera

import com.android.vadify.R
import com.android.vadify.databinding.FragmentCameraBinding
import com.android.vadify.ui.baseclass.BaseDaggerFragment

class CameraFragment : BaseDaggerFragment<FragmentCameraBinding>() {

    override val layoutRes: Int
        get() = R.layout.fragment_camera


}