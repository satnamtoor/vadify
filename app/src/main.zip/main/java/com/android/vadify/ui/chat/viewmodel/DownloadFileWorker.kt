/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.vadify.ui.chat.viewmodel

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.android.vadify.data.api.enums.DownloadUploadStatus
import com.android.vadify.data.api.enums.MessageType
import com.android.vadify.data.db.chat.ChatListCache
import com.android.vadify.di.WorkerKey
import com.android.vadify.utils.LocalStorage
import com.android.vadify.utils.LocalStorage.getFilePath
import dagger.Binds
import dagger.Module
import dagger.multibindings.IntoMap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.*
import java.net.URL
import java.net.URLConnection
import javax.inject.Inject


class DownloadFileWorker @Inject constructor(
    var context: Context,
    params: WorkerParameters,
    private var chatListCache: ChatListCache
) : CoroutineWorker(context, params) {

    companion object {
        const val URL = "url"
        const val TYPE = "type"
    }

    override suspend fun doWork(): Result {
        var count: Int
        var demoUrl = ""
        try {
            inputData.getString(URL)?.let {
                updateUrl(DownloadUploadStatus.IN_PROGRESS.value, it)
                demoUrl = it
                val file = File(it)
                val url = URL(it)
                val conexion: URLConnection = url.openConnection()
                conexion.connect()
                // this will be useful so that you can show a tipical 0-100% progress bar
                val localPath = filterFileName(file.name)
                val lenghtOfFile: Int = conexion.contentLength
                val input: InputStream = BufferedInputStream(url.openStream())
                val output: OutputStream = FileOutputStream(localPath)
                val data = ByteArray(1024)
                var total: Long = 0
                while (input.read(data).also { count = it } != -1) {
                    total += count.toLong()
                    Log.e("response are", "" + (total * 100 / lenghtOfFile).toInt())
                    output.write(data, 0, count)
                }
                output.flush()
                output.close()
                input.close()
                updateUrlOnDataBase(localPath, it)
            }

        } catch (e: Exception) {
            updateUrl(DownloadUploadStatus.FAILED.value, demoUrl)
            Log.e("response are ", "" + e.message.toString())
        }
        return Result.success()
    }

    private fun updateUrl(status: Int, liveUrl: String) {
        if (liveUrl.isNotBlank()) {
            chatListCache.updateDownloadStatus(status, liveUrl)
        }
    }


    private fun updateUrlOnDataBase(localPath: String, liveUrl: String) {
        CoroutineScope(Dispatchers.IO).launch {
            chatListCache.updateLocalUrl(localPath, liveUrl)
            updateUrl(DownloadUploadStatus.SUCCESS.value, liveUrl)
        }
    }

    private fun filterFileName(fileName: String): String {
        var filePath =
            context.getFilePath(LocalStorage.DOWNLOAD_DOCUMENT_FILE_PATH) + "/" + fileName
        inputData.getString(UploadFileWorker.TYPE)?.let {
            filePath = when (it) {
                MessageType.DOCUMENT.value -> context.getFilePath(LocalStorage.DOWNLOAD_DOCUMENT_FILE_PATH) + "/" + fileName
                MessageType.VIDEO.value -> context.getFilePath(LocalStorage.DOWNLOAD_VIDEO_FILE_PATH) + "/" + fileName
                MessageType.AUDIO.value -> context.getFilePath(LocalStorage.DOWNLOAD_AUDIO_FILE_PATH) + "/" + fileName
                else -> context.getFilePath(LocalStorage.DOWNLOAD_DOCUMENT_FILE_PATH) + "/" + fileName
            }
        }
        return filePath
    }


    @Module
    abstract class Builder {
        @Binds
        @IntoMap
        @WorkerKey(DownloadFileWorker::class)
        abstract fun bindHelloWorldWorker(worker: DownloadFileWorker): CoroutineWorker
    }

}
