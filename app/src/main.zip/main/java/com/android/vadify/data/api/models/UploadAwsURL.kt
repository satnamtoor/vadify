package com.android.vadify.data.api.models

data class UploadAwsURL(
    val type: String?,
    val contentType: String,
    val fileName: String?

)