package com.android.vadify.data.api.models

data class MarkChatAsReadRequest(
        val roomIds:List<String>
)