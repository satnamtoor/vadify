package com.android.vadify.data.api.models

data class StaticContentResponse(
    val data: String,
    val message: String,
    val statusCode: Int
)