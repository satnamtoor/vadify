package com.android.vadify.ui.login.fragment

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.android.vadify.R
import com.android.vadify.databinding.FragmentVerificationBinding
import com.android.vadify.ui.baseclass.BaseDaggerFragment
import com.android.vadify.ui.dashboard.Dashboard
import com.android.vadify.ui.login.viewmodel.LoginFragmentViewModel
import com.android.vadify.ui.login.viewmodel.ProfileFragmentViewModel
import com.android.vadify.widgets.numberFormat
import com.sdi.joyersmajorplatform.common.livedataext.throttleClicks
import com.sdi.joyersmajorplatform.common.progressDialog
import com.stfalcon.smsverifycatcher.OnSmsCatchListener
import com.stfalcon.smsverifycatcher.SmsVerifyCatcher
import kotlinx.android.synthetic.main.fragment_verification.*


class VerificationFragment : BaseDaggerFragment<FragmentVerificationBinding>() {
    override val layoutRes: Int
        get() = R.layout.fragment_verification

    private val args: VerificationFragmentArgs by navArgs()

    val viewModel: LoginFragmentViewModel by viewModels()
    lateinit var smsVerifyCatcher: SmsVerifyCatcher
    val viewModelProfile: ProfileFragmentViewModel by viewModels()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        updatePhoneNumber()
        toolbar.setNavigationOnClickListener {
            findNavController().popBackStack()
        }

        smsVerifyCatcher = SmsVerifyCatcher(requireActivity(), OnSmsCatchListener { message ->
            message?.let { viewModel.updateOtpCode(viewModel.parseCode(it)) }
        })

        subscribe(changeBtn.throttleClicks()) {
            findNavController().popBackStack()
        }

        subscribe(resendOtpBtn.throttleClicks()) {
            if (args.isChangePassword) {
                bindNetworkState(
                    viewModel.changePasswordRequest(),
                    progressDialog(R.string.sending)
                )
            } else {

                bindNetworkState(viewModel.otpVerfication(args.countryCode,args.phoneNumber), progressDialog(R.string.sending))
            }
        }

        subscribe(submitBtn.throttleClicks()) {
            //  findNavController().navigate(VerificationFragmentDirections.actionVerificationFragmentToPersonalInformationFragment())

            viewModel.filterMethod { isCondition, message ->
                when {

                    isCondition && !args.isChangePassword -> {

                        bindNetworkState(
                            viewModel.loginApiHit(args.countryCode, args.phoneNumber,args.userName),
                            progressDialog(R.string.verifying)
                        )
                        {
                            //findNavController().navigate(VerificationFragmentDirections.actionVerificationFragmentToPersonalInformationFragment())

                            bindNetworkState(
                                viewModelProfile.updateProfileData(args.userName),
                                progressDialog(R.string.updating))

                            val intent = Intent(requireContext(), Dashboard::class.java)
                            intent.putExtra(Dashboard.IS_FIRST_TIME, true)
                            startActivity(intent)
                            requireActivity().finish()

                        }
                    }
                    isCondition && args.isChangePassword -> {
                        bindNetworkState(
                            viewModel.changePasswordWithOtpReqeust(
                                args.countryCode,
                                args.phoneNumber
                            ), progressDialog(R.string.verifying)
                        ) {
                            requireActivity().finish()
                        }
                    }
                    else -> showSnackMessage(resources.getString(message ?: R.string.unknow_msg))
                }
            }
        }
    }


    private fun updatePhoneNumber() {
        val formatedNumber =
            requireContext().numberFormat(args.dialCode, args.countryCode, args.phoneNumber)
        viewModel.updatePhoneNumber(args.countryCode, formatedNumber, args.phoneNumber)
    }


    override fun onStart() {
        super.onStart()
        /* if (isAllGranted(Permission.RECEIVE_SMS, Permission.READ_SMS)) {
             smsVerifyCatcher.onStart()
         } else {*/
        //  runWithPermissions(Permission.RECEIVE_SMS, Permission.READ_SMS) {
        otpVerification.isCursorVisible == true
        smsVerifyCatcher.onStart()
        // }
        //}
    }

    override fun onStop() {
        super.onStop()
        smsVerifyCatcher.onStop()
    }


    override fun onBindView(binding: FragmentVerificationBinding) {
        binding.vm = viewModel
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        smsVerifyCatcher.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

}
