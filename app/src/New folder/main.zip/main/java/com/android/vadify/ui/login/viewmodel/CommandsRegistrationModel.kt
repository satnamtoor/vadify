package com.android.vadify.ui.login.viewmodel

class CommandsRegistrationModel {
}