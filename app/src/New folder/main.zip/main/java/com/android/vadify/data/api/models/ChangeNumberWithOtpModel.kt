package com.android.vadify.data.api.models

data class ChangeNumberWithOtpModel(
    val existingCountryCode: String?,
    val existingPhone: String?,
    val newCountryCode: String?,
    val newPhone: String?,
    val otp: String?
)


