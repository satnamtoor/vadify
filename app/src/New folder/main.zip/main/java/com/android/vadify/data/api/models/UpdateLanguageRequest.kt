package com.android.vadify.data.api.models

data class UpdateLanguageRequest(
    var language: String? = "",
    var languageCode: String? = "",
    var countryCode: String? = ""

)
