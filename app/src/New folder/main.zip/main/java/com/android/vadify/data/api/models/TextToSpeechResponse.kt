package com.android.vadify.data.api.models

data class TextToSpeechResponse(
    val audioContent: String
)